function uploadData() {
    const form = document.getElementById('uploadForm');
    const formData = new FormData(form);

    fetch('http://192.168.22.27:50001/api/test/upload', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            alert(data.data);
            console.log('Success:', data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
}

document.getElementById('uploadButton').addEventListener('click', function() {
    uploadData();
});
