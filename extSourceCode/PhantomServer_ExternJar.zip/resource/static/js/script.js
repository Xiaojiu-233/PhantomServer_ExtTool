document.getElementById('myButton').addEventListener('click', function() {
    document.getElementById('message').innerText = '按钮被点击了！';
});