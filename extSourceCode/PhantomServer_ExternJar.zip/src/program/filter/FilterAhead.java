package program.filter;

import xj.abstracts.web.Request;
import xj.annotation.ComponentImport;
import xj.interfaces.component.IConfigureManager;
import xj.interfaces.component.ILogManager;
import xj.interfaces.web.HttpWebFilter;

@ComponentImport
public class FilterAhead implements HttpWebFilter {

    // 成员属性
    private ILogManager logManager;

    // 成员方法
    @Override
    public boolean doFilter(Request request) {
        logManager.info("这是一个HTTP过滤器~");
        return true;
    }

    @Override
    public int getPriority() {
        return 1;
    }


}
