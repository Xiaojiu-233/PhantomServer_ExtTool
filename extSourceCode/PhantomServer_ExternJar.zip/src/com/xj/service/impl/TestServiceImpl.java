package com.xj.service.impl;

import com.xj.service.TestService;
import xj.abstracts.web.Response;
import xj.annotation.ComponentImport;
import xj.annotation.PService;
import xj.interfaces.component.ILogManager;
import xj.interfaces.mvc.MultipartFile;
import xj.interfaces.web.IHttpResponse;

import java.io.*;
import java.nio.file.Files;
import java.util.Map;
import java.util.logging.LogManager;

@PService
@ComponentImport
public class TestServiceImpl implements TestService {

    private ILogManager logManager;

    @Override
    public String readMap(Map<String, Object> map) {
        return map.toString();
    }

    @Override
    public void uploadFile(IHttpResponse response, MultipartFile file, String name) {
        logManager.info("读取到了 name 属性",name);
        ByteArrayInputStream bais = new ByteArrayInputStream(file.getDataBytes());
        writeFileByInputStream("D:\\Phantom\\webUpload\\" + name,bais);
    }

    private void writeFileByInputStream(String targetPath, InputStream source) {
        try {
            // 生成路径文件夹
            if(targetPath.lastIndexOf(File.separator) != -1){
                String dirPath = targetPath.substring(0, targetPath.lastIndexOf(File.separator));
                File dir = new File(dirPath);
                if(!dir.exists()){
                    if(!dir.mkdirs()){
                        logManager.error("执行数据存入文件系统任务时，无法创建文件夹: {}",dirPath);
                        return;
                    }
                }
            }
            // 打开文件
            File file = new File(targetPath);
            if (!file.exists())
                if(!file.createNewFile()){
                    logManager.error("执行数据存入文件系统任务时，无法创建文件: {}",targetPath);
                    return;
                }
            // 数据准备
            byte[] buffer = new byte[1024];// 开始读取数据
            OutputStream target = Files.newOutputStream(file.toPath());
            // 1.读取数据并存入文件中
            int getByte = 0;
            while ((getByte = source.read(buffer))!= -1) {
                // 数据
                target.write(buffer,0,getByte);
            }
            // 3.读取结束
            source.close();
            target.close();
        } catch (IOException e) {
            logManager.error("执行数据存入文件系统任务时，出现异常：{}",e);
        }
    }

}
