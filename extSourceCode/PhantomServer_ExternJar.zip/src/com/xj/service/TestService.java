package com.xj.service;

import xj.interfaces.mvc.MultipartFile;
import xj.interfaces.web.IHttpResponse;

import java.util.Map;

public interface TestService {

    String readMap(Map<String, Object> map);

    void uploadFile(IHttpResponse response, MultipartFile file, String name);
}
