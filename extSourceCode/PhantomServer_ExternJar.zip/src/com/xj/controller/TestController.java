package com.xj.controller;

import com.xj.pojo.TestPackage;
import com.xj.pojo.TestVO;
import com.xj.service.TestService;
import xj.annotation.*;
import xj.entity.web.Cookie;
import xj.enums.web.RequestMethod;
import xj.interfaces.component.ILogManager;
import xj.interfaces.mvc.MultipartFile;
import xj.interfaces.web.IHttpRequest;
import xj.interfaces.web.IHttpResponse;

import java.util.List;
import java.util.Map;

@PController
@PRequestMapping("/api/test")
@ComponentImport
public class TestController {

    // 成员属性
    @PAutowired
    private TestService testService;

    private ILogManager logManager;

    // 成员方法
    // 设置数据
    @PRequestMapping(value = "/set", method = RequestMethod.POST)
    public TestVO<Integer> setMessage(@PRequestBody Map<String,Object> body,
                             @PUploadFile Object file){
        logManager.info("开始读取消息");
        logManager.info("body",testService.readMap(body));
        if(file != null)
            logManager.info("static", file.toString());
        return TestVO.success(200);
    }

    // 上传文件
    @PRequestMapping(value = "/upload", method = RequestMethod.POST)
    public TestVO<String> uploadFile(IHttpResponse response,
                                      @PRequestBody Map<String,Object> body){
        logManager.info("开始上传文件");
        logManager.info("body",testService.readMap(body));
        testService.uploadFile(response, (MultipartFile) body.get("file")
                , (String) body.get("name"));
        return TestVO.success("文件上传成功");
    }

    // 读取服务端传来的数据
    @PRequestMapping(value = "/get", method = RequestMethod.GET)
    public TestVO<Void> getMessage(@PRequestParam Map<String,Object> param){
        logManager.info("开始读取消息");
        logManager.info("param",testService.readMap(param));
        return TestVO.failure("失败了");
    }

    // 读取服务的本地数据
    @PRequestMapping(value = "/getPkg", method = RequestMethod.GET)
    public TestVO<TestPackage> getPackage(){
        logManager.info("开始读取包裹");
        return TestVO.success(new TestPackage("xiaojiu",114));
    }

    // 从服务端获取Cookie
    @PRequestMapping(value = "/getCookie", method = RequestMethod.GET)
    public TestVO<Void> getCookie(IHttpResponse response){
        logManager.info("开始设置cookie");
        Cookie cookie = new Cookie("aaa","bbb");
        cookie.setExpires(10);
        response.setCookie(cookie);
        return TestVO.success(null);
    }

    // 读Cookie
    @PRequestMapping(value = "/readCookie", method = RequestMethod.GET)
    public TestVO<List<Cookie>> readCookie(IHttpRequest request){
        logManager.info("开始阅读cookie");
        return TestVO.success(request.getCookies());
    }

    // 等待
    @PRequestMapping(value = "/await", method = RequestMethod.POST)
    public void await(IHttpRequest request){
        logManager.info("开始等待");
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
