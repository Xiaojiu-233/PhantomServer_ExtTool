package com.xj.pojo;

public class TestPackage {

    // 成员属性
    private String name;

    private Integer id;

    // 成员行为
    public TestPackage() {
    }
    public TestPackage(String name, Integer id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Integer getId() {
        return id;
    }
}
