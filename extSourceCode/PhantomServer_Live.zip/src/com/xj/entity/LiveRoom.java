package com.xj.entity;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

// 直播间信息
public class LiveRoom {

    // 成员属性
    private int roomId;
    // 推流者地址（主播）
    private InetSocketAddress streamer;
    // 订阅者地址列表（观众）
    private ArrayList<InetSocketAddress> subscribers = new ArrayList<>();

    private final String LIVE_ROOM_NAME_TEMPLATE = "直播间-";

    // 成员行为
    // 初始化
    public LiveRoom(int roomId) {
        this.roomId = roomId;
    }

    // 获取直播间数据
    public Map<String,Object> getRoomInfo(){
        Map<String,Object> map = new HashMap<>();
        map.put("id",roomId);
        map.put("name",LIVE_ROOM_NAME_TEMPLATE + roomId);
        return map;
    }

    public void setStreamer(InetSocketAddress streamer) {
        this.streamer = streamer;
    }

    public ArrayList<InetSocketAddress> getSubscribers() {
        return subscribers;
    }

    public void addSubscriber(InetSocketAddress subscriber) {
        subscribers.add(subscriber);
    }

    public void removeSubscriber(InetSocketAddress subscriber) {
        subscribers.remove(subscriber);
    }
}
