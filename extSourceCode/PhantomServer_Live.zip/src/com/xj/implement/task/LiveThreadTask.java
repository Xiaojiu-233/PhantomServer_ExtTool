package com.xj.implement.task;

import com.xj.entity.LiveRoom;
import com.xj.util.LiveConstant;
import program.component.LiveManager;
import program.util.Logger;
import xj.abstracts.thread.ThreadTask;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LiveThreadTask extends ThreadTask {

    // 成员属性
    private final int port;// 直播服务器端口

    private final Map<Integer, LiveRoom> liveMapping;// 直播间映射

    private final Map<Integer, LiveRoom> watchMapping;// 观众映射

    // 成员行为
    // 初始化
    public LiveThreadTask() {
        port = LiveConstant.Config.LIVE_PORT;
        liveMapping = new HashMap<>();
        watchMapping = new HashMap<>();
    }

    @Override
    public void doTask() {
        // 初始化数据
        String threadName = Thread.currentThread().getName();
        ByteBuffer buffer = ByteBuffer.allocate(LiveConstant.Config.UDP_CACHE_SIZE); // UDP最大合理值
        try(DatagramChannel serverChannel = DatagramChannel.open()){
            serverChannel.configureBlocking(false);
            serverChannel.bind(new InetSocketAddress(port));
            while(true){
                buffer.clear();
                InetSocketAddress clientAddress = (InetSocketAddress) serverChannel.receive(buffer);
                if (clientAddress != null) {
                    buffer.flip();
                    // 解析
                    int roomId = clientAddress.getAddress().getHostAddress().hashCode();
                    LiveRoom room = liveMapping.get(roomId);
                    // 如果是新推流者，注册到房间
                    if (room == null) {
                        room = new LiveRoom(roomId);
                        room.setStreamer(clientAddress);
                        liveMapping.put(roomId, room);
                        // 注册房间之后，需要删除自己的观众身份（如果可能）
                        LiveRoom watchingRoom = watchMapping.get(roomId);
                        if (watchingRoom != null) {
                            watchingRoom.removeSubscriber(clientAddress);
                        }
                    }
                    // 转发给所有订阅者（排除推流者自己）
                    for (SocketAddress subscriber : room.getSubscribers()) {
                        if (!subscriber.equals(clientAddress)) {
                            buffer.rewind(); // 重置buffer位置
                            serverChannel.send(buffer, subscriber);
                        }
                    }
                }
            }
        } catch (IOException e) {
            Logger.getLogManager().error("[{}] 直播模块在执行程序时出现异常: {}",threadName,e);
        }
    }

    // 添加组播用户
    public boolean addSendGroupUser(String remoteIp,int id) {
        synchronized (this) {
            // 不能观看自己的直播
            InetSocketAddress watcher = new InetSocketAddress(remoteIp,LiveConstant.Config.LIVE_PORT);
            int watcherId = watcher.getAddress().getHostAddress().hashCode();
            if (watcherId == id){
                Logger.getLogManager().error("直播模块不允许用户观看自己的直播间",id);
                return false;
            }
            // 通过id寻找直播间，添加为组播
            LiveRoom room = liveMapping.get(id);
            if (room == null) {
                Logger.getLogManager().error("直播模块未找到对应id的直播间",id);
                return false;
            }
            room.addSubscriber(watcher);
            watchMapping.put(id,room);
            // 进入直播间之后，需要删除自己的主播身份（如果可能）
            liveMapping.remove(watcherId);
            return true;
        }
    }

    // 返回直播间信息
    public List<Map<String,Object>> getLiveRoomMessage(){
        // 整理数据数据
        List<Map<String,Object>> list = new ArrayList<>();
        synchronized (this) {
            liveMapping.values()
                    .forEach(entry -> {list.add(entry.getRoomInfo());});
        }
        return list;
    }

    @Override
    public void doDestroy() {

    }

    @Override
    public String getLogDescribe() {
        return "UDP直播管理任务";
    }
}
