package com.xj.implement.web;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xj.util.LiveConstant;
import program.util.Logger;
import xj.abstracts.web.Response;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Map;

public class LiveResponse extends Response {

    // 成员属性
    private String respJson;

    // 成员行为
    // 存储Map数据
    public void storeMapData(Map<String,Object> map) {
        try {
            respJson = new ObjectMapper().writeValueAsString(map);
        } catch (JsonProcessingException e) {
            Logger.getLogManager().error("",e);
        }
    }

    @Override
    public void writeMessage(SocketChannel os) throws IOException {
        // 写入响应
        String ret = LiveConstant.Noun.TCP + LiveConstant.Symbol.COLON +
                LiveConstant.Noun.LIVE + LiveConstant.Symbol.LINE_BREAK +
                LiveConstant.Symbol.LINE_BREAK +
                respJson + LiveConstant.Symbol.LINE_BREAK +
                unitSplitBreak + LiveConstant.Symbol.LINE_BREAK;
        // 写入响应
        byte[] bytes = ret.getBytes();
        ByteBuffer buffer = ByteBuffer.allocate(bytes.length);
        buffer.put(bytes);
        // 输出
        buffer.flip();
        os.write(buffer);
    }

    @Override
    public void storeData(byte[] bytes) {
        respJson = new String(bytes);
    }
}
