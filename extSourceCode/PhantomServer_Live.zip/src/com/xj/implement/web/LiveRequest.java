package com.xj.implement.web;

import com.xj.util.LiveConstant;
import program.util.Logger;
import xj.abstracts.web.Request;

public class LiveRequest extends Request {

    // 成员属性
    private String action;// 请求行为

    private int id;// 请求直播间id

    // 成员方法
    // 初始化
    public LiveRequest(Request request) {
        super(request.getData(), request.getHeadMsg(), request.getRemoteIp());
        selfAnalysis();
    }

    // 自解析
    private void selfAnalysis() {
        // 拆解数据
        String[] lines = encodeToString();
        // 判定数据是否符合规范
        if(lines.length < 3){
            Logger.getLogManager().error("请求内容不符合规范");
            return;
        }
        // 获取数据
        String reqAction = lines[2];
        if(reqAction.contains(LiveConstant.Symbol.COLON)){
            action = reqAction.substring(0,reqAction.indexOf(LiveConstant.Symbol.COLON));
            id = Integer.parseInt(reqAction.substring
                    (reqAction.indexOf(LiveConstant.Symbol.COLON)+1));
        }else{
            action = reqAction;
        }
    }

    public String getAction() {
        return action;
    }

    public int getId() {
        return id;
    }
}
