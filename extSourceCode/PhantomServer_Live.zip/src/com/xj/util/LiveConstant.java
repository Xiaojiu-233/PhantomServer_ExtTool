package com.xj.util;

public interface LiveConstant {

    interface Symbol{

        String POINT = ".";
        String EMPTY = "";
        String BACK_SLASH = "\\";
        String QUOTATION_MARK = "\"";
        String SLASH = "/";
        String COMMA = ",";
        String COLON = ":";
        String SEMICOLON = ";";
        String SPACE = " ";
        String UNDERLINE = "_";
        String HYPHEN = "-";
        String QUESTION_MARK = "?";
        String AND = "&";
        String EQUAL = "=";
        String LINE_BREAK = "\r\n";
    }

    interface Noun{
        String TCP = "TCP";
        String LIVE = "LIVE";
        String OPEN = "open";
        String GET_LIST = "getList";
        String WATCH = "watch";
        String PORT = "port";
        String LIVE_LIST = "liveList";
    }

    interface Config{

        int LIVE_PORT = 50002;// 直播服务器端口

        int UDP_CACHE_SIZE = 65535;// UDP缓存单元大小
    }
}
