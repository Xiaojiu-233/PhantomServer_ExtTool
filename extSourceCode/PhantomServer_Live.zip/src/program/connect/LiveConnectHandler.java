package program.connect;

import com.xj.implement.web.LiveRequest;
import program.component.LiveManager;
import xj.abstracts.connect.ConnectHandler;
import xj.abstracts.web.Request;
import xj.abstracts.web.Response;
import xj.annotation.ComponentImport;
import xj.interfaces.component.ILogManager;

// 直播业务连接处理器
@ComponentImport
public class LiveConnectHandler extends ConnectHandler {

    // 成员属性
    private ILogManager logManager;

    private final String TCP_LIVE = "TCP_LIVE";

    // 成员方法
    @Override
    public boolean isMatchedRequest(String s) {
        return s.length() == TCP_LIVE.length() && TCP_LIVE.equals(s);
    }

    @Override
    protected Response handle(Request request) {
        // 将协议请求转化为直播业务请求
        LiveRequest liveRequest = new LiveRequest(request);
        // 转交给直播模块进行处理
        return LiveManager.getInstance().handle(liveRequest);
    }

    @Override
    public Response whenException() {
        return LiveManager.getInstance().failResp();
    }
}
