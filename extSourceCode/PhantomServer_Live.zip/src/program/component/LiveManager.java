package program.component;

import com.xj.implement.task.LiveThreadTask;
import com.xj.implement.web.LiveRequest;
import com.xj.implement.web.LiveResponse;
import com.xj.util.LiveConstant;
import program.util.Logger;
import xj.abstracts.thread.ThreadTask;
import xj.annotation.ComponentImport;
import xj.interfaces.component.ILogManager;
import xj.interfaces.component.IThreadPoolManager;
import xj.interfaces.ioc.Instantiation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// 直播业务管理器
@ComponentImport
public class LiveManager implements Instantiation {

    // 成员属性
    private static volatile LiveManager instance;// 单例模式实现

    private ILogManager logManager;

    private IThreadPoolManager threadPoolManager;

    private LiveThreadTask liveThreadTask;// 直播业务线程任务

    // 成员方法
    // 初始化
    @Override
    public void instantiate() {
        logManager.info("【直播模块】开始初始化");
        logManager.info("直播模块参数 -> 监听端口"
                , LiveConstant.Config.LIVE_PORT);
        instance = this;
        initThread();
        logManager.info("【直播模块】初始化完成");
    }

    private void initThread(){
        logManager.info("【直播模块】正在初始化业务线程任务...");
        LiveThreadTask task = new LiveThreadTask();
        threadPoolManager.putThreadTask(task);
    }

    // 获取单例（防止高并发导致资源访问问题进行双判空保护）
    public static LiveManager getInstance() {
        if(instance == null)
            synchronized (LiveManager.class){
                if(instance == null)
                    instance = new LiveManager();
            }
        return instance;
    }

    // 处理数据
    public LiveResponse handle(LiveRequest req) {
        Map<String,Object> ret = new HashMap<>();
        // 分析数据
        String action = req.getAction();
        if (action == null || action.isEmpty()) {
            logManager.error("直播模块收到非法请求，无法处理");
            return failResp();
        }
        else if (action.equals(LiveConstant.Noun.GET_LIST)) {
            // 填入数据
            ret.put(LiveConstant.Noun.LIVE_LIST, liveThreadTask.getLiveRoomMessage());
        }
        else if (action.equals(LiveConstant.Noun.WATCH)) {
            if(liveThreadTask.addSendGroupUser(req.getRemoteIp(), req.getId()))
                ret.put(LiveConstant.Noun.PORT, LiveConstant.Config.LIVE_PORT);
            else
                return failResp();
        }
        // 填写响应信息
        LiveResponse response = new LiveResponse();
        response.storeMapData(ret);
        return response;
    }

    // 删除id对应直播间映射信息
    public void removeLiveMappingById(int id) {
    }

    // 返回失败响应
    public LiveResponse failResp() {
        LiveResponse response = new LiveResponse();
        Map<String,Object> failMsg = new HashMap<>();
        failMsg.put("result", "fail");
        response.storeMapData(failMsg);
        return response;
    }
}
