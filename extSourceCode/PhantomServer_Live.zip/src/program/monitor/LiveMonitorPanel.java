package program.monitor;

import xj.interfaces.component.MonitorPanel;

import java.util.Collections;
import java.util.Map;

public class LiveMonitorPanel implements MonitorPanel {

    @Override
    public String returnTitle() {
        return "直播";
    }

    @Override
    public String returnWebpagePath() {
        return "/webpage/LiveMonitorPanel.html";
    }

    @Override
    public Map<String, Object> getData(Map<String, Object> map) {
        return Collections.emptyMap();
    }

    @Override
    public void setData(Map<String, Object> map) {

    }
}
