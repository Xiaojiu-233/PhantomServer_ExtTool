package program.util;

import xj.annotation.ComponentImport;
import xj.interfaces.component.ILogManager;

// 公用日志记录器
@ComponentImport
public class Logger {

    // 成员属性
    private static ILogManager logManager;

    // 成员方法
    // 获取日志管理器
    public static ILogManager getLogManager() {
        return logManager;
    }
}
